import{S as s,i as r,s as t}from"../../chunks/vendor-82895fbc.js";export default class extends s{constructor(s){super(),r(this,s,null,null,t,{})}}
